import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class GetuserService {

  url = 'https://randomuser.me/api';
  user: string;

  constructor(private myHttp: HttpClient) { }

  getUserApi(){
    this.myHttp.get(this.url)
    .subscribe(
      response => {
      this.user = response['results'];
    });
  }
}
