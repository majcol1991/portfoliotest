import { Component, OnInit } from '@angular/core';
import { GetuserService } from '../service/getuser.service';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-user-img',
  templateUrl: './user-img.component.html',
  styleUrls: ['./user-img.component.css']
})
export class UserImgComponent implements OnInit {

  url = 'https://randomuser.me/api';
  user: string;

  constructor(public getUserService: GetuserService, private myHttp: HttpClient) { }

  ngOnInit(): void {

  this.myHttp.get(this.url)
      .subscribe(
        response => {
          this.user = response['results'];
      });
    }
  }


