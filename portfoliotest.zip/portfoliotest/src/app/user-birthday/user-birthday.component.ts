import { Component, OnInit } from '@angular/core';
import { GetuserService } from '../service/getuser.service';

@Component({
  selector: 'app-user-birthday',
  templateUrl: './user-birthday.component.html',
  styleUrls: ['./user-birthday.component.css']
})
export class UserBirthdayComponent implements OnInit {

  constructor(public getUserService: GetuserService) { }

  ngOnInit(): void {
    this.getUserService.getUserApi();
  }

}
