import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserTelephoneComponent } from './user-telephone.component';

describe('UserTelephoneComponent', () => {
  let component: UserTelephoneComponent;
  let fixture: ComponentFixture<UserTelephoneComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserTelephoneComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserTelephoneComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
