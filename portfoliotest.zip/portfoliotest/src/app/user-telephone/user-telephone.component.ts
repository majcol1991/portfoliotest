import { Component, OnInit } from '@angular/core';
import { GetuserService } from '../service/getuser.service';

@Component({
  selector: 'app-user-telephone',
  templateUrl: './user-telephone.component.html',
  styleUrls: ['./user-telephone.component.css']
})
export class UserTelephoneComponent implements OnInit {

  constructor(public getUserService: GetuserService) { }

  ngOnInit(): void {
    this.getUserService.getUserApi();
  }

}
