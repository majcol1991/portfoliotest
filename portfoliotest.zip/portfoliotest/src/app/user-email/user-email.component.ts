import { Component, OnInit } from '@angular/core';
import { GetuserService } from '../service/getuser.service';

@Component({
  selector: 'app-user-email',
  templateUrl: './user-email.component.html',
  styleUrls: ['./user-email.component.css']
})
export class UserEmailComponent implements OnInit {

  constructor(public getUserService: GetuserService) { }

  ngOnInit(): void {
    this.getUserService.getUserApi();
  }

}
