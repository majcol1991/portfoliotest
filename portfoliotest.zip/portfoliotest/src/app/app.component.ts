import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  isShowName: boolean = true;
  isShowEmail: boolean = true;
  isShowAddres: boolean = true;
  isShowBthd: boolean = true;
  isShowTeleph: boolean = true;
  isShowPsw: boolean = true;

  constructor(){}

  toggleShowName = () => this.isShowName = !this.isShowName;
  toggleShowEmail = () => this.isShowEmail = !this.isShowEmail;
  toggleShowAddres = () => this.isShowAddres = !this.isShowAddres;
  toggleShowBthd = () =>  this.isShowBthd= !this.isShowBthd;
  toggleShowTeleph = () =>  this.isShowTeleph = !this.isShowTeleph;
  toggleShowPsw = () =>  this.isShowPsw = !this.isShowPsw;



}
