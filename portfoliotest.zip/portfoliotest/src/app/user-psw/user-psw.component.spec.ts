import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserPswComponent } from './user-psw.component';

describe('UserPswComponent', () => {
  let component: UserPswComponent;
  let fixture: ComponentFixture<UserPswComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserPswComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserPswComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
