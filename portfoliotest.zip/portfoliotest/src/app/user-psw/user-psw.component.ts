import { Component, OnInit } from '@angular/core';
import { GetuserService } from '../service/getuser.service';

@Component({
  selector: 'app-user-psw',
  templateUrl: './user-psw.component.html',
  styleUrls: ['./user-psw.component.css']
})
export class UserPswComponent implements OnInit {

  constructor(public getUserService: GetuserService) { }

  ngOnInit(): void {
    this.getUserService.getUserApi();
  }

}
