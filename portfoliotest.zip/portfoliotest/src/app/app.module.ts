import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { UserNameComponent } from './user-name/user-name.component';
import { UserEmailComponent } from './user-email/user-email.component';
import { UserBirthdayComponent } from './user-birthday/user-birthday.component';
import { UserAddressComponent } from './user-address/user-address.component';
import { UserTelephoneComponent } from './user-telephone/user-telephone.component';
import { UserPswComponent } from './user-psw/user-psw.component';
import { UserImgComponent } from './user-img/user-img.component';

@NgModule({
  declarations: [
    AppComponent,
    UserNameComponent,
    UserEmailComponent,
    UserBirthdayComponent,
    UserAddressComponent,
    UserTelephoneComponent,
    UserPswComponent,
    UserImgComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
